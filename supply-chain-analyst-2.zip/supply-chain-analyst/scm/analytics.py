"""Core supply chain analytics: ABC, EOQ, safety stock, reorder point, forecasting, MAPE."""
from math import sqrt
from statistics import NormalDist

import numpy as np
import pandas as pd


def abc_classification(df, item_col="sku", value_col="annual_value", a=0.80, b=0.95):
    """Pareto/ABC: A = items making up the first 80% of value, B = next 15%, C = rest."""
    out = df.groupby(item_col, as_index=False)[value_col].sum()
    out = out.sort_values(value_col, ascending=False).reset_index(drop=True)
    share = out[value_col] / out[value_col].sum()
    out["cum_share"] = share.cumsum()
    prev = out["cum_share"] - share  # share accumulated before this item
    out["abc_class"] = np.where(prev < a, "A", np.where(prev < b, "B", "C"))
    return out


def eoq(annual_demand, order_cost, holding_cost):
    """Economic Order Quantity = sqrt(2*D*S/H)."""
    if min(annual_demand, order_cost, holding_cost) <= 0:
        raise ValueError("All inputs must be positive")
    return sqrt(2 * annual_demand * order_cost / holding_cost)


def safety_stock(service_level, avg_daily_demand, std_daily_demand,
                 avg_lead_time_days, std_lead_time_days=0.0):
    """z * sqrt(LT*sigma_d^2 + d^2*sigma_LT^2)."""
    z = NormalDist().inv_cdf(service_level)
    var = avg_lead_time_days * std_daily_demand ** 2 + (avg_daily_demand ** 2) * std_lead_time_days ** 2
    return z * sqrt(var)


def reorder_point(avg_daily_demand, avg_lead_time_days, safety_stock_units):
    """ROP = demand during lead time + safety stock."""
    return avg_daily_demand * avg_lead_time_days + safety_stock_units


def moving_average_forecast(series, window=3):
    """Forecast for each period t = mean of the previous `window` periods."""
    s = pd.Series(series, dtype=float)
    return s.rolling(window).mean().shift(1)


def exponential_smoothing_forecast(series, alpha=0.3):
    """Simple exponential smoothing; forecast[t] uses data up to t-1."""
    s = pd.Series(series, dtype=float)
    f = [np.nan, s.iloc[0]]
    for t in range(1, len(s) - 1):
        f.append(alpha * s.iloc[t] + (1 - alpha) * f[-1])
    return pd.Series(f[: len(s)], index=s.index)


def mape(actual, forecast):
    """Mean Absolute Percentage Error (%), skipping periods with no forecast or zero actual."""
    a = pd.Series(actual, dtype=float)
    f = pd.Series(forecast, dtype=float)
    mask = f.notna() & (a != 0)
    return float((abs((a[mask] - f[mask]) / a[mask])).mean() * 100)


def inventory_turnover(cogs, avg_inventory_value):
    return cogs / avg_inventory_value if avg_inventory_value else float("nan")


def sku_policy_table(sales, service_level=0.95, order_cost=500.0, holding_rate=0.2,
                     lead_time_days=7, lead_time_std=1.5):
    """Per-SKU EOQ / safety stock / ROP from daily sales (cols: date, sku, units, unit_cost)."""
    rows = []
    for sku, g in sales.groupby("sku"):
        d_avg, d_std = g["units"].mean(), g["units"].std(ddof=1)
        cost = g["unit_cost"].iloc[0]
        ss = safety_stock(service_level, d_avg, d_std, lead_time_days, lead_time_std)
        rows.append({
            "sku": sku,
            "avg_daily_demand": round(d_avg, 2),
            "eoq": round(eoq(d_avg * 365, order_cost, cost * holding_rate), 1),
            "safety_stock": round(ss, 1),
            "reorder_point": round(reorder_point(d_avg, lead_time_days, ss), 1),
        })
    return pd.DataFrame(rows)
