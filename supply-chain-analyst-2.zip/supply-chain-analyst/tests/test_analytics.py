import pandas as pd
import pytest

from scm.analytics import (abc_classification, eoq, mape, moving_average_forecast,
                           reorder_point, safety_stock)


def test_eoq_known_value():
    assert eoq(1000, 10, 2) == pytest.approx(100.0)


def test_safety_stock_95_percent():
    assert safety_stock(0.95, 10, 5, 4) == pytest.approx(16.449, abs=0.01)


def test_reorder_point():
    assert reorder_point(10, 5, 20) == 70


def test_mape():
    assert mape([100, 200], [110, 180]) == pytest.approx(10.0)


def test_moving_average_uses_previous_periods():
    f = moving_average_forecast([10, 20, 30, 40], window=2)
    assert f.iloc[2] == 15 and f.iloc[3] == 25


def test_abc_classes():
    df = pd.DataFrame({"sku": list("abcd"), "annual_value": [800, 100, 60, 40]})
    out = abc_classification(df).set_index("sku")["abc_class"]
    assert out["a"] == "A" and out["d"] == "C"
